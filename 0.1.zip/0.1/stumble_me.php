<?php
/**
Plugin Name: Stumble Me
Plugin URI: http://techofweb.com/plugins/share-posts-stumbleupon-stumble.html
Description:  Wordpress Plugin that allows your visitors to share your posts to Stumble Upon. This plugin displays stumble icon at the right hand side of beginning of your each post. Total Stumble views of that post are also shown.

Version: 0.1
Author: Atul Kumar
Author URI: http://www.techofweb.com
Stable Tag: trunk
License: A "Slug" license name e.g. GPL2


  Copyright 2010 Atul Kumar (email : oceanofweb@gmail.com) (Blog: http://techofweb.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA


INSTRUCTIONS
------------
1. Download the plugin from http://www.techofweb.com/wp-downloads/stumble-me.zip
2. Extract and upload the contents of the archive to 'yourserver.com/wp-content/plugins/stumble-me/'
3. Login to your Wordpress admin panel and browse to the Plugins section.
4. Activate the Stumble Me Wordpress Plugin.

**/


	add_filter('the_content', 'stumble_me_display');
	
		function stumble_me_display($content='') {
			if (is_single())
			return stumble_me() . $content;
		  
			return $content;
		}

	function stumble_me() {	
	$button = '<div style="float: right; margin-left: 10px;"><script src="http://www.stumbleupon.com/hostedbadge.php?s=5"></script></div>';
	}

?>
